const $ = (selector) => document.querySelector(selector);
const STORAGE_KEY = "zenith-ai-conversations-v1";
let currentMessages = [];
let currentConversationId = null;
let isSending = false;
let toastTimer;

function safeParse(value, fallback) {
  try { return JSON.parse(value) ?? fallback; } catch { return fallback; }
}
function getHistory() {
  const data = safeParse(localStorage.getItem(STORAGE_KEY), []);
  return Array.isArray(data) ? data : [];
}
function saveCurrentConversation() {
  if (!currentMessages.length) return;
  const history = getHistory();
  const id = currentConversationId || (currentConversationId = crypto.randomUUID());
  const oldIndex = history.findIndex(item => item.id === id);
  const conversation = {
    id, title: currentMessages.find(m => m.role === "user")?.content.slice(0, 58) || "New conversation",
    updatedAt: new Date().toISOString(), messages: currentMessages
  };
  if (oldIndex >= 0) history.splice(oldIndex, 1);
  history.unshift(conversation);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(0, 50)));
}
function toast(message) {
  const el = $("#toast");
  el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
}
function showPanel(name) {
  document.querySelectorAll(".view").forEach(el => el.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.panel === name));
  const map = { chat: "#chatView", knowledge: "#knowledgeView", memory: "#memoryView" };
  $(map[name] || "#chatView").classList.add("active");
  $("#pageTitle").innerHTML = ({ chat: 'AI Chat <span class="beta">BETA</span>', knowledge: "Knowledge base", memory: "Memory & history" })[name];
  $("#sidebar").classList.remove("open");
  if (name === "knowledge") loadKnowledge();
  if (name === "memory") renderHistory();
}
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[char]);
}
// Minimal markdown treatment: escapes HTML first, then supports code and line breaks.
function formatText(text) {
  let output = escapeHtml(text);
  output = output.replace(/```([\s\S]*?)```/g, (_m, code) => `<pre><code>${code.trim()}</code></pre>`);
  output = output.replace(/`([^`]+)`/g, "<code>$1</code>");
  output = output.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  return output.replace(/\n/g, "<br>");
}
function renderMessages() {
  const area = $("#messages");
  area.innerHTML = "";
  area.classList.toggle("has-messages", currentMessages.length > 0);
  $("#welcome").style.display = currentMessages.length ? "none" : "";
  for (const message of currentMessages) {
    const row = document.createElement("article");
    row.className = `message ${message.role === "user" ? "user" : "assistant"}`;
    row.innerHTML = `<div class="message-avatar">${message.role === "user" ? "Y" : "Z"}</div><div class="message-body"><div class="message-name">${message.role === "user" ? "You" : "Zenith AI"}</div><div class="message-text">${formatText(message.content)}</div></div>`;
    area.appendChild(row);
  }
  area.scrollTop = area.scrollHeight;
}
function addTyping() {
  const area = $("#messages");
  const row = document.createElement("article");
  row.className = "message"; row.id = "typingIndicator";
  row.innerHTML = '<div class="message-avatar">Z</div><div class="message-body"><div class="message-name">Zenith AI</div><div class="typing"><i></i><i></i><i></i></div></div>';
  area.appendChild(row); area.scrollTop = area.scrollHeight;
}
async function sendMessage(text) {
  const message = text.trim();
  if (!message || isSending) return;
  isSending = true; $("#sendButton").disabled = true;
  currentMessages.push({ role: "user", content: message });
  renderMessages(); saveCurrentConversation();
  $("#prompt").value = ""; $("#prompt").style.height = "auto";
  addTyping();
  try {
    const history = currentMessages.slice(0, -1).slice(-12);
    const response = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history })
    });
    const data = await response.json().catch(() => ({}));
    $("#typingIndicator")?.remove();
    if (!response.ok) throw new Error(data.error || "The request failed.");
    currentMessages.push({ role: "assistant", content: data.answer });
    saveCurrentConversation(); renderMessages();
    if (data.usedKnowledge?.length) toast(`Used knowledge: ${data.usedKnowledge.join(", ")}`);
  } catch (error) {
    $("#typingIndicator")?.remove();
    currentMessages.push({ role: "assistant", content: `Sorry, I couldn't complete that request.\n\n${error.message}` });
    saveCurrentConversation(); renderMessages();
  } finally {
    isSending = false; $("#sendButton").disabled = false; $("#prompt").focus();
  }
}
function startNewChat() {
  currentMessages = []; currentConversationId = null; renderMessages(); $("#prompt").focus();
  showPanel("chat");
}
function renderHistory() {
  const history = getHistory();
  $("#historyCount").textContent = `${history.length} conversation${history.length === 1 ? "" : "s"}`;
  const area = $("#historyList"); area.innerHTML = "";
  if (!history.length) { area.innerHTML = '<div class="empty-state">No saved conversations yet.<br>Start chatting and your conversations will appear here.</div>'; return; }
  history.forEach(item => {
    const row = document.createElement("div"); row.className = "history-card";
    const button = document.createElement("button"); button.className = "load-history";
    const title = document.createElement("b"); title.textContent = item.title || "Conversation";
    const meta = document.createElement("small"); meta.textContent = `${(item.messages || []).length} messages · ${new Date(item.updatedAt).toLocaleString()}`;
    button.append(title, meta);
    button.addEventListener("click", () => {
      currentConversationId = item.id; currentMessages = Array.isArray(item.messages) ? item.messages : [];
      renderMessages(); showPanel("chat");
    });
    const del = document.createElement("button"); del.className = "delete-button"; del.textContent = "Delete";
    del.addEventListener("click", () => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(getHistory().filter(h => h.id !== item.id)));
      if (currentConversationId === item.id) startNewChat();
      renderHistory(); toast("Conversation deleted.");
    });
    row.append(button, del); area.appendChild(row);
  });
}
async function loadKnowledge() {
  try {
    const response = await fetch("/api/knowledge");
    const items = await response.json();
    if (!response.ok) throw new Error(items.error || "Could not load knowledge.");
    $("#knowledgeCount").textContent = items.length;
    $("#knowledgeSubtitle").textContent = `${items.length} item${items.length === 1 ? "" : "s"}`;
    const area = $("#knowledgeList"); area.innerHTML = "";
    if (!items.length) { area.innerHTML = '<div class="empty-state">Your knowledge base is empty.<br>Add notes above to give Zenith useful context.</div>'; return; }
    items.forEach(item => {
      const card = document.createElement("div"); card.className = "knowledge-card";
      const icon = document.createElement("div"); icon.className = "doc-icon"; icon.textContent = "▤";
      const info = document.createElement("div"); info.className = "doc-info";
      const title = document.createElement("b"); title.textContent = item.title;
      const preview = document.createElement("p"); preview.textContent = item.content.slice(0, 220) + (item.content.length > 220 ? "…" : "");
      info.append(title, preview);
      const del = document.createElement("button"); del.className = "delete-button"; del.textContent = "Delete";
      del.addEventListener("click", async () => {
        if (!confirm(`Delete "${item.title}" from the knowledge base?`)) return;
        const result = await fetch(`/api/knowledge/${encodeURIComponent(item.id)}`, { method: "DELETE" });
        if (!result.ok) { toast("Could not delete that item."); return; }
        loadKnowledge(); toast("Knowledge item deleted.");
      });
      card.append(icon, info, del); area.appendChild(card);
    });
  } catch { toast("Could not connect to the knowledge API."); }
}
async function checkHealth() {
  try {
    const response = await fetch("/api/health"); const data = await response.json();
    $("#statusTitle").textContent = data.configured ? "AI connected" : "Setup needed";
    $("#statusText").textContent = data.configured ? `Model: ${data.model}` : "Add your API key to .env";
    $("#knowledgeCount").textContent = data.knowledgeCount ?? 0;
  } catch {
    $("#statusTitle").textContent = "Server unavailable";
    $("#statusText").textContent = "Start the Node.js server";
  }
}

$("#chatForm").addEventListener("submit", event => { event.preventDefault(); sendMessage($("#prompt").value); });
$("#prompt").addEventListener("input", event => {
  event.target.style.height = "auto";
  event.target.style.height = `${Math.min(event.target.scrollHeight, 180)}px`;
});
$("#prompt").addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); $("#chatForm").requestSubmit(); }
});
$("#newChat").addEventListener("click", startNewChat);
$("#clearChat").addEventListener("click", startNewChat);
$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
document.querySelectorAll(".nav-item").forEach(button => button.addEventListener("click", () => showPanel(button.dataset.panel)));
document.querySelectorAll("[data-prompt]").forEach(button => button.addEventListener("click", () => {
  showPanel("chat"); $("#prompt").value = button.dataset.prompt; $("#prompt").focus();
}));
$("#knowledgeForm").addEventListener("submit", async event => {
  event.preventDefault();
  const title = $("#knowledgeTitle").value.trim(), content = $("#knowledgeText").value.trim();
  if (!title || !content) return;
  try {
    const response = await fetch("/api/knowledge", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, content }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not save.");
    $("#knowledgeTitle").value = ""; $("#knowledgeText").value = "";
    await loadKnowledge(); toast("Knowledge added successfully.");
  } catch (error) { toast(error.message); }
});
$("#deleteHistory").addEventListener("click", () => {
  if (!getHistory().length || !confirm("Clear all saved conversations from this browser?")) return;
  localStorage.removeItem(STORAGE_KEY); currentMessages = []; currentConversationId = null;
  renderMessages(); renderHistory(); toast("Conversation history cleared.");
});
renderMessages(); checkHealth();