# Zenith AI

A responsive, purple-black AI workspace with an API-backed chat, browser-saved conversation history, and a small persistent text knowledge base.

## Features

- Responsive mobile and desktop chat UI
- OpenAI-compatible chat completions endpoint (provider can be configured)
- API key stays on the server in `.env`, not in browser JavaScript
- Add, view, and delete text knowledge items
- Simple keyword matching injects relevant knowledge into chat context
- Up to 50 conversation histories saved in the current browser
- Basic request-size limits and security headers

## Requirements

- Node.js 20+
- An API key for an AI provider that supports the OpenAI-compatible `/chat/completions` format

## Run locally

1. Download/clone the repository.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Put your own API key in `.env` and set `AI_MODEL` / `AI_BASE_URL` for your provider.
5. Start the app:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000`.

Never commit `.env` or paste API keys into public issues, chats, or source code. If a key was exposed, revoke it at the provider and create a replacement.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `PORT` | Port for the server (default `3000`) |
| `AI_API_KEY` | Secret API key, required for AI responses |
| `AI_BASE_URL` | Provider API base URL (default `https://api.openai.com/v1`) |
| `AI_MODEL` | Model name available to your provider |
| `CLIENT_ORIGIN` | Optional allowed origin if you later host the frontend separately |

## API routes

- `GET /api/health` — reports whether a key is configured, the configured model, and knowledge count (never returns the key)
- `POST /api/chat` — `{ "message": "...", "history": [] }`
- `GET /api/knowledge` — list saved knowledge items
- `POST /api/knowledge` — `{ "title": "...", "content": "..." }`
- `DELETE /api/knowledge/:id` — remove a knowledge item

## Important limitations

- This is a functional starter, not a trained or fine-tuned model. The knowledge base uses lightweight keyword matching and adds matching notes to a prompt; it does not change model weights.
- Knowledge is stored in `data/knowledge.json` on the server. On hosting platforms with ephemeral filesystems, use a persistent disk or replace this storage with a database.
- Conversation history is stored in the current browser's local storage. It does not sync across devices or users.
- There is no authentication or multi-user isolation yet. Do not expose this instance publicly with private information until authentication, rate limiting, and proper per-user data access are added.
- Uploaded PDFs/images and admin/model settings are not included in this first version.
- Check the AI provider's pricing, quota, privacy terms, and model availability before use.
